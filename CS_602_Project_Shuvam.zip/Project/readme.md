Welcome to our chat app!

================
Getting Started:
================

There are runnable .jar files named ClientServer.jar and ClientChatApp.jar. What we have to do is just double click those runnable files and they will run. The Server requires a host name to host the server. Our program will automatically detect the ip address of the host machine and start the server. 
	In the client app we need to provide an username and host IP address and our program will automatically connect it. It uses a secure algorithm to secure chats and help it from being stolen. 
	We can create multile clients and connect to the server. Our app is completely portable from one device to another. It will run on any java supported machine.

===========
Depenciies:
===========

	Our app only needs a java environment to run and thats all!


=====================
Security Functions ::
=====================

* This app is secured by encryption.
* It does not contain any harmful contains
* We do not store your data
* All chats are self-destructive. i.e After chat messages will be deleted
* there is a logout function to help logging out from the app


================
TroubleShooting
================

If you are unable to execute the java files then probably you have no executable permission for the jar file in your pc. In that case please grant permission.
To do so in linux type "chmod +x "file name"" in terminal.
For further assistance please contact "shuvam1309@gmail.com"


============
Developers
============

Shuvam Ghosh (27)
Sourav Dhabal (24)
Sudeshna Hazra (22)
Prity Choudhary (42)
Ayan Mondal (55)


==============
Contact Info :
==============

Email: shuvam1309@gmail.com
phone: 7003141268




